let localPromotions = [];
let Carrito = [];

class FetchPromotion {
  constructor(promotionsEndpoint) {
    this.promotionsEndpoint = promotionsEndpoint;
  }

  async getPromotions() {
    const fetchedPromotions = await fetch(this.promotionsEndpoint);
    return fetchedPromotions.json();
  }
}

const fetchPromotion = new FetchPromotion("./data/promociones.json");

fetchPromotion.getPromotions().then((promotions) => {
  if (localStorage.getItem("usuarioCarrito")) {
    Carrito = JSON.parse(localStorage.getItem("usuarioCarrito"));
  }
  localPromotions = promotions;
  let promotionsContainer = document.getElementById("promotions-container");

  const mappedPromotions = promotions.map((promotion, index) => {
    return `<div class="card ml-5">
      <img src="${promotion.imagen}" class="card-img-top" alt="Promociones">
      <div class="card-body">
        <h3 class="card-title tituloCard">${promotion.nombre}</h3>
      </div>
    <div>
      <button style="margin-left: 100px" type="button" id="agregarParrilla0${
        index + 1
      }" onclick="agregarProducto(${promotion.id})">
        +
      </button>	
    </div>
    <div style=" margin-inline: auto"> 			
      <div style="text-align: center;" id="promotion-${promotion.id}">
      ${Carrito.filter((x) => x.id === promotion.id).length}	
    </div>
    <div>
      <button style="margin-right: 100px;" type="button" id="descontarParrilla0${
        index + 1
      }" onclick="descontarProducto(${promotion.id})">
        -
      </button>	
    </div>
  </div>
   </div>`;
  });
  promotionsContainer.innerHTML = mappedPromotions;
});

function agregarProducto(promotionId) {
  const promotionUnidad = document.getElementById("promotion-" + promotionId);
  const currentPromotionUnidadValue = parseInt(promotionUnidad.textContent);
  promotionUnidad.innerText = currentPromotionUnidadValue + 1;
  const selectedPromotion = localPromotions.find(
    (promotion) => promotion.id === promotionId
  );
  Carrito.push(selectedPromotion);
  localStorage.setItem("usuarioCarrito", JSON.stringify(Carrito));
}

function descontarProducto(promotionId) {
  const promotionUnidad = document.getElementById("promotion-" + promotionId);
  const currentPromotionUnidadValue = parseInt(promotionUnidad.textContent);
  if (currentPromotionUnidadValue > 0) {
    promotionUnidad.innerText = currentPromotionUnidadValue - 1;
    const promotionIndex = Carrito.findIndex(
      (promotion) => promotion.id === promotionId
    );
    if (promotionIndex !== -1) {
      Carrito.splice(promotionIndex, 1);
      localStorage.setItem("usuarioCarrito", JSON.stringify(Carrito));
    }
  }
}



function imprimirPedido() {
  let text = "";
  const groupedPromotions = Carrito.reduce((r, a) => {
    r[a.id] = [...(r[a.id] || []), a];
    return r;
  }, {});

  Object.keys(groupedPromotions).forEach((groupedPromotionKey) => {
    const groupedQuantity = groupedPromotions[groupedPromotionKey].length;
    const promotionName = groupedPromotions[groupedPromotionKey][0].nombre;
    text += `<b>Producto:</b> ${promotionName}   <b>Cantidad:</b>  ${groupedQuantity}  <br /> `;

    
  });
  let totalCarrito = 0;
  Carrito.forEach((carritoItem) => {
    totalCarrito += carritoItem.precio;
  });
  text += `Total de la compra es $ ${totalCarrito} <br /> `;
  return text;
}

const btn = document.getElementById("botonCarro");

btn.addEventListener("click", () => {
  Swal.fire({
    title: "Desea confirmar su pedido?",
    html: imprimirPedido(),
    imageUrl:
      "multimedia/carro.png",
      imageWidth: 200,
      imageHeight: 200,
    imageAlt: "Custom image",

    showCancelButton: true,
    confirmButtonText: "Confirmar",
    cancelButtonText: "Vaciar",
  }).then((result) => {
    if (result.isConfirmed) {
      Swal.fire({
        title: "¡Gracias por su compra!",
        icon: "info",
        text: "El pedido esta en Camino",
      });
    } else {
      Carrito = [];
      Swal.fire({
        title: "Borrado!",
        icon: "success",
        text: "Su carrito ha sido borrado",
      });
    }

    /*   pedidoNuevo.descartar();
    pedidoNuevo.storage(); */
  });
});












class Pedido {
  constructor(parrilla01Unidad, parrilla02Unidad, Parrilla03Unidad) {
    this.parrilla01Unidad = parrilla01Unidad | 0;
    this.parrilla02Unidad = parrilla02Unidad | 0;
    this.Parrilla03Unidad = Parrilla03Unidad | 0;
    this.pedidoFinal = [];
  }

  descartar() {
    this.parrilla02Unidad = 0;
    this.parrilla01Unidad = 0;
    this.Parrilla03Unidad = 0;
  }

  storage() {
    const enJSON = JSON.stringify(this);
    localStorage.setItem("usuarioCarrito", enJSON);
  }

  CompletarPedido() {
    this.pedidoFinal.push({ Parrilla01: this.parrilla01Unidad });
    this.pedidoFinal.push({ Parrilla02: this.parrilla02Unidad });
    this.pedidoFinal.push({ Parrilla03: this.Parrilla03Unidad });
  }
}

var pedidoNuevo = new Pedido(0, 0, 0);

function AgregarParrilla01() {
  pedidoNuevo.parrilla01Unidad = pedidoNuevo.parrilla01Unidad + 1;
  Display_Parrilla01.innerText = pedidoNuevo.parrilla01Unidad;
}

function DescontarParrilla01() {
  if (pedidoNuevo.parrilla01Unidad > 0) {
    pedidoNuevo.parrilla01Unidad = pedidoNuevo.parrilla01Unidad - 1;
  }
  Display_Parrilla01.innerText = pedidoNuevo.parrilla01Unidad;
  pedidoNuevo.storage();
}

function AgregarParrilla02() {
  pedidoNuevo.parrilla02Unidad = pedidoNuevo.parrilla02Unidad + 1;
  Display_Parrilla02.innerText = pedidoNuevo.parrilla02Unidad;
  pedidoNuevo.storage();
}

function DescontarParrilla02() {
  if (pedidoNuevo.parrilla02Unidad > 0) {
    pedidoNuevo.parrilla02Unidad = pedidoNuevo.parrilla02Unidad - 1;
  }
  Display_Parrilla02.innerText = pedidoNuevo.parrilla02Unidad;
  pedidoNuevo.storage();
}

function AgregarParrilla03() {
  pedidoNuevo.Parrilla03Unidad = pedidoNuevo.Parrilla03Unidad + 1;
  Display_Parrilla03.innerText = pedidoNuevo.Parrilla03Unidad;
  pedidoNuevo.storage();
}

function DescontarEstufa() {
  if (pedidoNuevo.Parrilla03Unidad > 0) {
    pedidoNuevo.Parrilla03Unidad = pedidoNuevo.Parrilla03Unidad - 1;
  }
  Display_Parrilla03.innerText = pedidoNuevo.Parrilla03Unidad;
  pedidoNuevo.storage();
}

var chulengo = 0;
var asador = 0;
var estufa = 0;
var modelo = "";
var finalChulengo = 0;
var finalAsador = 0;
var finalEstufa = 0;
var total = 0;

const precioChulengo = 20000;
const precioAsador = 30000;
const precioEstufa = 40000;
const descuento = 0.95;




 function seleccionarChulengo() {
  modelo = "Chulengo Tromen";
  chulengo = parseInt(
    prompt(
      "¡DESTACADOS DEL MES!\nChulengo Patagonico\nMarca: Tromen\n\n Precio por unidad $" +
        precioChulengo +
        " \nDescuento del 5% para cantidades superiores a 3 Unidades \n\nIngrese la cantidad:"
    )
  );
  invalido(chulengo, modelo);
  finalChulengo = operaciones(chulengo, modelo, precioChulengo, finalChulengo);
  return finalChulengo;
}
 

function seleccionarAsador() {
  modelo = "Asador Ñuke";
  asador = parseInt(
    prompt(
      "Asador Ñuke\n Precio por unidad $" +
        precioAsador +
        "\nDescuento del 5% para cantidades superiores a 3 Unidades\n\nIngrese la cantidad:"
    )
  );
  invalido(asador, modelo);
  finalAsador = operaciones(asador, modelo, precioAsador, finalAsador);
  return finalAsador;
}

function seleccionarEstufa() {
  modelo = "Estufas Ñuke";
  estufa = parseInt(
    prompt(
      "Estufas Ñuke\n\nPrecio por unidad $" +
        precioEstufa +
        " \nDescuento del 5% para cantidades superiores a 3 Unidades\n\nIngrese la cantidad:"
    )
  );
  invalido(estufa, modelo);
  finalEstufa = operaciones(estufa, modelo, precioEstufa, finalEstufa);
  return finalEstufa;
}

class carrito {
  constructor(cantChulengo, cantAsador, cantEstufa) {
    this.cantChulengo = cantChulengo;
    this.cantAsador = cantAsador;
    this.cantEstufa = cantEstufa;

    this.lista = function () {
      console.log(
        "\n\nProductos: " +
          "\n" +
          cantChulengo +
          " Chulengos" +
          "\n" +
          cantAsador +
          " Asadores" +
          "\n" +
          cantEstufa +
          " Estufas"
      );
    };

    this.calcular = function () {
      total = finalChulengo + finalAsador + finalEstufa;

      console.log(
        "\n\nPRECIO FINAL\n\n Chulengos | Cantidad: " +
          cantChulengo +
          " / Subtotal: " +
          finalChulengo +
          "\nAsadores| Cantidad: " +
          cantAsador +
          " / Subtotal: " +
          finalAsador +
          "\nEstufas | Cantidad: " +
          cantEstufa +
          " / Subtotal: " +
          finalEstufa +
          "\n\nTOTAL: $" +
          total
      );
      alert(
        "PRECIO FINAL\n\n Chulengos | Cantidad: " +
          cantChulengo +
          " / Subtotal: " +
          finalChulengo +
          "\n Asadores  | Cantidad: " +
          cantAsador +
          " / Subtotal: " +
          finalAsador +
          "\n Estufas   | Cantidad: " +
          cantEstufa +
          " / Subtotal: " +
          finalEstufa +
          "\n\nTOTAL: $" +
          total
      );
    };
  }
}

var usuarioCarrito;
function totalCarrito() {
  usuarioCarrito = new carrito(chulengo, asador, estufa);

  usuarioCarrito.calcular();
  usuarioCarrito.lista();

  const enJSON = JSON.stringify(usuarioCarrito.pedido);

  localStorage.setItem("usuarioCarrito", enJSON);

  let carritoEnLS = JSON.stringify(localStorage.getItem("usuarioCarrito"));

  console.log(carritoEnLS);
}

function invalido(numero) {
  if (isNaN(numero) || numero < 0) {
    alert("La cantidad ingresada es inválida");
  }
}

function operaciones(unidad, modelo, precio, final) {
  if (unidad == 1 || unidad == 0 || unidad == 2) {
    final = unidad * precio;
    console.log("Cantidad de " + modelo + ":" + unidad + "\nPrecio: $" + final);
    alert("Cantidad de " + modelo + ": " + unidad + "\nPrecio: $" + final);
    alertFinal1 =
      "Cantidad de " + modelo + ": " + unidad + "\nPrecio: $" + final;
  }
  if (unidad >= 3) {
    final = unidad * (precio * descuento);
    console.log(
      "Cantidad de " + modelo + ": " + unidad + "\nPrecio: $" + final
    );
    alert("Cantidad de " + modelo + ": " + unidad + "\nPrecio: $" + final);
  }
  return final;
}
